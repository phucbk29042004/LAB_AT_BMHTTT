package week_01;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;

public class frm_TanCong extends javax.swing.JFrame {

    private JTextArea txt_cipher;
    private JButton btn_bruteforce;
    private JButton btn_frequency;
    private JTextField txt_known_plain;
    private JTextField txt_known_cipher;
    private JButton btn_known;
    private JTextArea txt_result;
    private JLabel lbl_status;

    public frm_TanCong() {
        initComponents();
        setLocationRelativeTo(null);
    }

    private void initComponents() {
        setTitle("Phân tích mật mã cổ điển");
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel lblTitle = new JLabel("PHÂN TÍCH (TẤN CÔNG) MẬT MÃ CỔ ĐIỂN", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 18));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 4;
        panel.add(lblTitle, gbc);

        JLabel lblCipher = new JLabel("Ciphertext:");
        lblCipher.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 4;
        panel.add(lblCipher, gbc);

        txt_cipher = new JTextArea(2, 40);
        txt_cipher.setLineWrap(true);
        txt_cipher.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        JScrollPane spCipher = new JScrollPane(txt_cipher);
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 4;
        panel.add(spCipher, gbc);

        JPanel btnPanel1 = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        btn_bruteforce = new JButton("Brute Force Caesar");
        btn_frequency = new JButton("Frequency Analysis");
        btnPanel1.add(btn_bruteforce);
        btnPanel1.add(btn_frequency);
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 4;
        panel.add(btnPanel1, gbc);

        JPanel knownPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        knownPanel.add(new JLabel("Bản rõ đã biết:"));
        txt_known_plain = new JTextField("HELLO", 8);
        knownPanel.add(txt_known_plain);

        knownPanel.add(new JLabel("Bản mã:"));
        txt_known_cipher = new JTextField("RIJVS", 8);
        knownPanel.add(txt_known_cipher);

        btn_known = new JButton("Known Plaintext (Vigenere)");
        knownPanel.add(btn_known);

        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 4;
        panel.add(knownPanel, gbc);

        JLabel lblResult = new JLabel("Kết quả:");
        lblResult.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 4;
        panel.add(lblResult, gbc);

        txt_result = new JTextArea(14, 45);
        txt_result.setEditable(false);
        txt_result.setLineWrap(false);
        txt_result.setFont(new Font("Monospaced", Font.PLAIN, 12));
        JScrollPane spResult = new JScrollPane(txt_result);
        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.gridwidth = 4;
        panel.add(spResult, gbc);

        lbl_status = new JLabel("Sẵn sàng.");
        lbl_status.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lbl_status.setForeground(new Color(60, 60, 60));
        gbc.gridx = 0;
        gbc.gridy = 7;
        gbc.gridwidth = 4;
        panel.add(lbl_status, gbc);

        getContentPane().add(panel);
        pack();

        btn_bruteforce.addActionListener(evt -> btn_bruteforceActionPerformed(evt));
        btn_frequency.addActionListener(evt -> btn_frequencyActionPerformed(evt));
        btn_known.addActionListener(evt -> btn_knownActionPerformed(evt));
    }

    private void btn_bruteforceActionPerformed(java.awt.event.ActionEvent evt) {
        String cipher = txt_cipher.getText().trim();
        if (cipher.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Hãy nhập Ciphertext.");
            return;
        }
        txt_result.setText(AttackDemos.caesarBruteForce(cipher));
        txt_result.setCaretPosition(0);
        lbl_status.setText("Đã thử đủ 26 khóa Caesar.");
    }

    private void btn_frequencyActionPerformed(java.awt.event.ActionEvent evt) {
        String cipher = txt_cipher.getText().trim();
        if (cipher.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Hãy nhập Ciphertext.");
            return;
        }
        txt_result.setText(AttackDemos.frequency(cipher));
        txt_result.setCaretPosition(0);
        lbl_status.setText("Đã thống kê tần suất chữ cái.");
    }

    private void btn_knownActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            String key = AttackDemos.knownPlaintext(txt_known_plain.getText(), txt_known_cipher.getText());
            txt_result.setText("Khóa Vigenère suy ra từng vị trí: " + key
                    + "\nNếu khóa ngắn hơn bản rõ, khóa sẽ lặp lại (KEY KEY ...).");
            lbl_status.setText("Khóa suy ra: " + key);
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(),
                    "Dữ liệu không hợp lệ", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new frm_TanCong().setVisible(true));
    }
}