package week_01;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;

public class frm_LichSu extends javax.swing.JFrame {

    private JTable tbl_history;
    private JButton btn_refresh;
    private JLabel lbl_status;

    public frm_LichSu() {
        initComponents();
        setLocationRelativeTo(null);
        tbl_history.setModel(HistoryDao.emptyModel());
        loadData();
    }

    private void initComponents() {
        setTitle("Lịch sử thao tác (SQL Server)");
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JLabel lblTitle = new JLabel("LỊCH SỬ THAO TÁC - BẢNG DBO.HISTORY", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 18));
        panel.add(lblTitle, BorderLayout.NORTH);

        tbl_history = new JTable();
        tbl_history.setRowHeight(22);
        tbl_history.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        JScrollPane scrollPane = new JScrollPane(tbl_history);
        scrollPane.setPreferredSize(new Dimension(760, 260));
        panel.add(scrollPane, BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel(new BorderLayout(10, 10));
        btn_refresh = new JButton("Tải lại");
        btn_refresh.setPreferredSize(new Dimension(110, 30));
        lbl_status = new JLabel("Đang tải...");
        lbl_status.setFont(new Font("Segoe UI", Font.PLAIN, 12));

        bottomPanel.add(btn_refresh, BorderLayout.WEST);
        bottomPanel.add(lbl_status, BorderLayout.CENTER);

        panel.add(bottomPanel, BorderLayout.SOUTH);

        getContentPane().add(panel);
        pack();

        btn_refresh.addActionListener(evt -> btn_refreshActionPerformed(evt));
    }

    private void loadData() {
        try {
            tbl_history.setModel(HistoryDao.loadLatest(50));
            lbl_status.setText("Đã tải " + tbl_history.getRowCount() + " dòng mới nhất từ dbo.history.");
        } catch (java.sql.SQLException ex) {
            lbl_status.setText("Không đọc được lịch sử: " + ex.getMessage());
        }
    }

    private void btn_refreshActionPerformed(java.awt.event.ActionEvent evt) {
        loadData();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new frm_LichSu().setVisible(true));
    }
}