package week_01;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

public class frm_Menu extends javax.swing.JFrame {

    private JButton btn_caesar;
    private JButton btn_vigenere;
    private JButton btn_railfence;
    private JButton btn_playfair;
    private JButton btn_transposition;
    private JButton btn_autokey;
    private JButton btn_tonghop;
    private JButton btn_tancong;
    private JButton btn_sql;

    public frm_Menu() {
        initComponents();
        setLocationRelativeTo(null);
    }

    private void initComponents() {
        setTitle("LAB 1 - Mã hóa đối xứng cổ điển");
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        JPanel panel = new JPanel(new BorderLayout(15, 15));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 25, 20, 25));

        JPanel headerPanel = new JPanel(new GridLayout(2, 1, 5, 5));
        JLabel lblTitle = new JLabel("LAB 1 - MÃ HÓA ĐỐI XỨNG CỔ ĐIỂN", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 20));
        JLabel lblSubtitle = new JLabel("Chọn một bài để mở form tương ứng:", SwingConstants.LEFT);
        lblSubtitle.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        headerPanel.add(lblTitle);
        headerPanel.add(lblSubtitle);
        panel.add(headerPanel, BorderLayout.NORTH);

        JPanel gridPanel = new JPanel(new GridLayout(3, 3, 12, 12));
        gridPanel.setPreferredSize(new Dimension(620, 150));

        btn_caesar = new JButton("1.1 Caesar");
        btn_vigenere = new JButton("1.2 Vigenère");
        btn_railfence = new JButton("1.3 Rail Fence");
        btn_playfair = new JButton("1.4 Playfair");
        btn_transposition = new JButton("1.5 Transposition");
        btn_autokey = new JButton("1.6 Autokey");
        btn_tonghop = new JButton("Nâng cao 01 - Tổng hợp");
        btn_tancong = new JButton("Nâng cao 02 - Tấn công");
        btn_sql = new JButton("Kết nối SQL Server");

        Font btnFont = new Font("Segoe UI", Font.PLAIN, 13);
        JButton[] buttons = {btn_caesar, btn_vigenere, btn_railfence, btn_playfair,
                             btn_transposition, btn_autokey, btn_tonghop, btn_tancong, btn_sql};
        for (JButton btn : buttons) {
            btn.setFont(btnFont);
            gridPanel.add(btn);
        }

        panel.add(gridPanel, BorderLayout.CENTER);

        JLabel lblFooter = new JLabel("Mỗi form mở ra là một cửa sổ riêng; đóng form con không làm tắt chương trình.", SwingConstants.CENTER);
        lblFooter.setFont(new Font("Segoe UI", Font.ITALIC, 12));
        lblFooter.setForeground(new Color(80, 80, 80));
        panel.add(lblFooter, BorderLayout.SOUTH);

        getContentPane().add(panel);
        pack();

        btn_caesar.addActionListener(evt -> btn_caesarActionPerformed(evt));
        btn_vigenere.addActionListener(evt -> btn_vigenereActionPerformed(evt));
        btn_railfence.addActionListener(evt -> btn_railfenceActionPerformed(evt));
        btn_playfair.addActionListener(evt -> btn_playfairActionPerformed(evt));
        btn_transposition.addActionListener(evt -> btn_transpositionActionPerformed(evt));
        btn_autokey.addActionListener(evt -> btn_autokeyActionPerformed(evt));
        btn_tonghop.addActionListener(evt -> btn_tonghopActionPerformed(evt));
        btn_tancong.addActionListener(evt -> btn_tancongActionPerformed(evt));
        btn_sql.addActionListener(evt -> btn_sqlActionPerformed(evt));
    }

    private void btn_caesarActionPerformed(java.awt.event.ActionEvent evt) {
        new frm_Caesar().setVisible(true);
    }

    private void btn_vigenereActionPerformed(java.awt.event.ActionEvent evt) {
        new frm_Vigenere().setVisible(true);
    }

    private void btn_railfenceActionPerformed(java.awt.event.ActionEvent evt) {
        new frm_RailFence().setVisible(true);
    }

    private void btn_playfairActionPerformed(java.awt.event.ActionEvent evt) {
        new frm_Playfair().setVisible(true);
    }

    private void btn_transpositionActionPerformed(java.awt.event.ActionEvent evt) {
        new frm_Transposition().setVisible(true);
    }

    private void btn_autokeyActionPerformed(java.awt.event.ActionEvent evt) {
        new frm_Autokey().setVisible(true);
    }

    private void btn_tonghopActionPerformed(java.awt.event.ActionEvent evt) {
        new frm_TongHop().setVisible(true);
    }

    private void btn_tancongActionPerformed(java.awt.event.ActionEvent evt) {
        new frm_TanCong().setVisible(true);
    }

    private void btn_sqlActionPerformed(java.awt.event.ActionEvent evt) {
        new frm_KetNoiSQL().setVisible(true);
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {
        }

        SwingUtilities.invokeLater(() -> new frm_Menu().setVisible(true));
    }
}